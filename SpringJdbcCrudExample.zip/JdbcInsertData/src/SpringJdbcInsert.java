import org.springframework.jdbc.core.JdbcTemplate;
public class SpringJdbcInsert
{
	JdbcTemplate jt;//has-a
	
	public void setJt(JdbcTemplate jt)
	{
		this.jt = jt;
	}
	public void insertRow()
	{
		int k = jt.update("insert into emp1 values(4,'qwerty')");
		
		System.out.println(k+ " row(s) inserted");
		
	}
}
//ddl->execute(create,alter,drop,rename,truncate)
//dml->update(insert,update,delete)
//drl->query(select)