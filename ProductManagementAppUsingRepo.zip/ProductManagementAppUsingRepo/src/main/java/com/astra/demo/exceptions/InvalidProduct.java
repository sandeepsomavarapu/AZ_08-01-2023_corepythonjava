package com.astra.demo.exceptions;

public class InvalidProduct extends Exception {
	public InvalidProduct(String message) {
		super(message);
	}
}
