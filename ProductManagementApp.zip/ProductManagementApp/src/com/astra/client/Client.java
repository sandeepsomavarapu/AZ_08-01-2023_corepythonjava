package com.astra.client;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

import com.astra.model.Product;

public class Client {

	public static void main(String[] args) {
		int productId;
		String productName;
		float productPrice;
		String productCategory;
		String productBrandName;
		Product product;
		HashMap<Integer, Product> products = new HashMap<Integer, Product>();
		Scanner scan = new Scanner(System.in);
		System.out.println("************ProductManagementApp*********");
		while (true) {
			System.out.println("1) Add Product");
			System.out.println("2) Update Product");
			System.out.println("3) Delete Product");
			System.out.println("4) Get ProductInfo");
			System.out.println("5) Get All Products");
			System.out.println("6) GetALL Products In between Price");
			System.out.println("7) GetAll Products By Category");
			System.out.println("8) GetAll Products By Brand");
			System.out.println("9) Exit");

			int option = scan.nextInt();

			switch (option) {
			case 1:
				System.out.println("Enter Product Info To Save");
				System.out.println("Enter ProductId :");
				productId = scan.nextInt();
				System.out.println("Enter ProductName :");
				productName = scan.next();
				System.out.println("Enter Product Price :");
				productPrice = scan.nextFloat();
				System.out.println("Enter Product Category :");
				productCategory = scan.next();
				System.out.println("Enter Product Brand :");
				productBrandName = scan.next();
				product = new Product(productId, productName, productPrice, productCategory, productBrandName);
				products.put(productId, product);
				System.out.println("Product Saved Successfully");
				break;
			case 2:
				System.out.println("Enter Product Info To Update");
				System.out.println("Enter Exsisting ProductId :");
				productId = scan.nextInt();
				System.out.println("Enter ProductName :");
				productName = scan.next();
				System.out.println("Enter Product Price :");
				productPrice = scan.nextFloat();
				System.out.println("Enter Product Category :");
				productCategory = scan.next();
				System.out.println("Enter Product Brand :");
				productBrandName = scan.next();
				product = new Product(productId, productName, productPrice, productCategory, productBrandName);
				products.put(productId, product);
				System.out.println("Product Updated Successfully");
				break;
			case 3:
				System.out.println("Enter Exsisting ProductId To Delete:");
				productId = scan.nextInt();
				products.remove(productId);
				System.out.println("Product Removed Successfully");
				break;
			case 4:
				System.out.println("Enter Exsisting Id To Get Product Info");
				productId = scan.nextInt();
				Product productInfo = products.get(productId);
				System.out.println(productInfo);
				break;
			case 5:
				Set<Integer> keys = products.keySet();
				Iterator<Integer> itr = keys.iterator();
				while (itr.hasNext()) {
					int key = itr.next();
					System.out.println(products.get(key));
				}
				break;
			case 6:
				System.out.println("Enter Product IntialPrice :");
				float intialPrice = scan.nextFloat();
				System.out.println("Enter Product finalPrice :");
				float finalPrice = scan.nextFloat();
				keys = products.keySet();
				itr = keys.iterator();
				while (itr.hasNext()) {
					int key = itr.next();
					productInfo = products.get(key);
					productPrice = productInfo.getProductPrice();
					if (productPrice > intialPrice && productPrice < finalPrice)
						System.out.println(productInfo);
				}
				break;
			case 7:
				System.out.println("Enter Product Category :");
				String category = scan.next();
				keys = products.keySet();
				itr = keys.iterator();
				while (itr.hasNext()) {
					int key = itr.next();
					productInfo = products.get(key);
					productCategory = productInfo.getProductCategory();
					if (category.equals(productCategory))
						System.out.println(productInfo);
				}
				break;
			case 8:
				System.out.println("Enter Product Brand :");
				String brand = scan.next();
				keys = products.keySet();
				itr = keys.iterator();
				while (itr.hasNext()) {
					int key = itr.next();
					productInfo = products.get(key);
					productBrandName = productInfo.getProductBrandName();
					if (brand.equals(productBrandName))
						System.out.println(productInfo);
				}
				break;
			default:
				System.out.println("Thank You!!!");
				scan.close();
				System.exit(0);
				break;
			}

		}
	}

}
