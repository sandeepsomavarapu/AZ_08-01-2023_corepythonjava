package com.astra.demo.service;

import java.util.List;

import com.astra.demo.exceptions.InvalidProduct;
import com.astra.demo.model.Product;

public interface ProductService {
	public abstract String addProduct(Product product);

	public abstract String updateProduct(Product product);

	public abstract String deleteProduct(int productId) throws InvalidProduct;

	public abstract Product getProduct(int productId) throws InvalidProduct;

	public abstract List<Product> getAllProducts();

	public abstract List<Product> getProductsBetweenPrice(int intialPrice, int finalPrice);

	public abstract List<Product> getProductsByCateogry(String productCategory);

	public abstract List<Product> getProductsByBrand(String productBrand);

}
