package com.astra.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.astra.demo.model.Product;
import com.astra.demo.repo.ProductRepo;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductRepo repo;

	@Override
	public String addProduct(Product product) {

		return repo.addProduct(product);
	}

	@Override
	public String updateProduct(Product product) {

		return repo.updateProduct(product);
	}

	@Override
	public String deleteProduct(int productId) {

		return repo.deleteProduct(productId);
	}

	@Override
	public Product getProduct(int productId) {

		return repo.getProduct(productId);
	}

	@Override
	public List<Product> getAllProducts() {

		return repo.getAllProducts();
	}

	@Override
	public List<Product> getProductsBetweenPrice(int intialPrice, int finalPrice) {

		return repo.getProductsBetweenPrice(intialPrice, finalPrice);
	}

	@Override
	public List<Product> getProductsByCateogry(String productCategory) {

		return repo.getProductsByCateogry(productCategory);
	}

	@Override
	public List<Product> getProductsByBrand(String productBrand) {

		return repo.getProductsByBrand(productBrand);
	}

}
