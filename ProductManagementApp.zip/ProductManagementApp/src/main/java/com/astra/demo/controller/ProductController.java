package com.astra.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.astra.demo.model.Product;
import com.astra.demo.service.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {
	@Autowired
	ProductService service;

	@PostMapping("/addProduct") // http://localhost:1234/products/addProduct
	public String insertProduct(@RequestBody Product product) {

		return service.addProduct(product);

	}

	@PutMapping("/updateProduct") // http://localhost:1234/products/updateProduct
	public String updateProduct(@RequestBody Product product) {

		return service.updateProduct(product);

	}

	@DeleteMapping("/deleteProduct/{pid}") // http://localhost:1234/products/deleteProduct/123
	public String removeProduct(@PathVariable("pid") int productId) {

		return service.deleteProduct(productId);

	}

	@GetMapping("/getProduct/{pid}") // http://localhost:1234/products/getProduct/123
	public Product getProduct(@PathVariable("pid") int productId) {

		return service.getProduct(productId);

	}

	@GetMapping("/getAll") // http://localhost:1234/products/getAll
	public List<Product> getAllProducts() {

		return service.getAllProducts();

	}

	@GetMapping("/getAllBetween/{price1}/{price2}") // http://localhost:1234/products/getAllBetween/1000/2000
	public List<Product> getAllProducts(@PathVariable("price1") int intialPrice,
			@PathVariable("price2") int finalPrice) {

		return service.getProductsBetweenPrice(intialPrice, finalPrice);

	}

	@GetMapping("/getAllByCategory/{category}") // http://localhost:1234/products/getAllByCategory/toys
	public List<Product> getAllProductsByCategory(@PathVariable("category") String category) {

		return service.getProductsByCateogry(category);

	}

	@GetMapping("/getAllByBrand/{brand}") // http://localhost:1234/products/getAllByBrand/samsung
	public List<Product> getAllProductsByBrand(@PathVariable("brand") String brand) {
		System.out.println("brand :"+brand);
		return service.getProductsByBrand(brand);

	}

}
