package com.astra.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "products_info")
public class Product {
	@Id
	@Column(name = "pid")
	@Min(value = 1000, message = "Product Id can't be below 1000")
	private int productId;
	@Column(name = "pname")
	@NotEmpty(message = "name can't be empty or null")
	@NotBlank(message = "name can't be blank or null")
	private String productName;
	@Min(value = 1000, message = "price can't be below 1000")
	@Max(value = 100000, message = "price can't be above 100000")
	private int productPrice;
	@Size(min = 5, max = 10, message = "category length must be between 5 to 10")
	private String productCategory;
	private String productBrand;

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public String getProductBrand() {
		return productBrand;
	}

	public void setProductBrand(String productBrand) {
		this.productBrand = productBrand;
	}

	public Product() {
		// TODO Auto-generated constructor stub
	}

	public Product(int productId, String productName, int productPrice, String productCategory, String productBrand) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
		this.productCategory = productCategory;
		this.productBrand = productBrand;
	}

}
