package com.astra.demo.repo;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.astra.demo.model.Product;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;

@Repository
public class ProductRepoImpl implements ProductRepo {
	@PersistenceContext
	EntityManager em;

	@Override
	public String addProduct(Product product) {
		em.persist(product);
		return "Product Saved Successfully";
	}

	@Override
	public String updateProduct(Product product) {
		em.merge(product);
		return "Product Updated Successfully";
	}

	@Override
	public String deleteProduct(int productId) {
		em.remove(getProduct(productId));
		return "Product Removed Sucessfully";
	}

	@Override
	public Product getProduct(int productId) {

		return em.find(Product.class, productId);
	}

	@Override
	public List<Product> getAllProducts() {
		TypedQuery<Product> tq = em.createQuery("select p from Product p", Product.class);
		return tq.getResultList();
	}

	@Override
	public List<Product> getProductsBetweenPrice(int intialPrice, int finalPrice) {
		TypedQuery<Product> tq = em.createQuery("select p from Product p where p.productPrice between ?1 and ?2",
				Product.class);
		tq.setParameter(1, intialPrice);
		tq.setParameter(2, finalPrice);
		return tq.getResultList();
	}

	@Override
	public List<Product> getProductsByCateogry(String productCategory) {
		TypedQuery<Product> tq = em.createQuery("select p from Product p where p.productCategory=?1", Product.class);
		tq.setParameter(1, productCategory);
		return tq.getResultList();
	}

	@Override
	public List<Product> getProductsByBrand(String productBrand) {
		TypedQuery<Product> tq = em.createQuery("select p from Product p where p.productBrand=?1", Product.class);
		tq.setParameter(1, productBrand);
		return tq.getResultList();
	}

}
