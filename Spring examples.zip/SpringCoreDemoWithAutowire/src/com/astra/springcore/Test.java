package com.astra.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		// Employee emp = new Employee(123, "suresh", 12000, "trainer");//tightly
		// coupled
		// System.out.println(emp);

//		Resource resource = new ClassPathResource("springconfig.xml");
//		BeanFactory factory = new XmlBeanFactory(resource);//lazy initializer
		
		ApplicationContext factory=new ClassPathXmlApplicationContext("springconfig.xml");//Eager Initializer
		
		Employee emp = (Employee) factory.getBean("emp");//bean scope -->singleton
		System.out.println(emp);
		System.out.println(emp.getAddress());
	
		

	}

}
