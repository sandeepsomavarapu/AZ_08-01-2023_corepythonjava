package com.astra.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class TestEmployee {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("mysql");
		EntityManager entityManager = emf.createEntityManager();//persist()--insert,merge()--update,remove()-->delete,find()-->select
		//DML-->insert,update,delete 
		entityManager.getTransaction().begin();
		
//		Employee emp=new Employee(123, "mahesh",12000, "trainer");
//		entityManager.persist(emp);
		
		Employee emp=entityManager.find(Employee.class, 123);
		System.out.println(emp);
//		emp.setEmpSal(20000);
//		entityManager.merge(emp);
		
		entityManager.remove(emp);
		entityManager.getTransaction().commit();
		
		
		
	}

}
