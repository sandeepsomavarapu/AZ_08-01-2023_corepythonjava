package com.cg.mvc.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.mvc.dao.EmpDao;
import com.cg.mvc.dto.Emp;


@Service("empService")
@Transactional
public class EmpServiceImpl implements EmpService {

	@Autowired
	EmpDao empDao;
	@Override
	public Emp save(Emp emp) {
		return empDao.save(emp);
	}
	@Override
	public Emp update(Emp emp) {
		
		return empDao.update(emp);
	}
	@Override
	public void delete(int id) {
		empDao.delete(id);
	}
	@Override
	public Emp getEmpById(int id) {
		return empDao.getEmpById(id);
	}
	@Override
	public List<Emp> getEmployees() {
		
		return empDao.getEmployees();
	}
}