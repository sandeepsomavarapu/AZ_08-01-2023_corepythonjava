import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class TestClient {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("sleeping");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
//insert
//
//		int i=1;
//		Employee e = new Employee("suresh", 10000);
//		Employee e1 = new Employee( "naresh", 20000);
//		Employee e2 = new Employee( "ramesh", 30000);
//		Employee e3 = new Employee( "rajesh", 40000);
//		em.persist(e);
//		em.persist(e1);
//		em.persist(e2);
//		em.persist(e3);// find()-1 record,JPQL

//		
//		Employee emp = em.find(Employee.class, 1);
//		System.out.println(emp);
//fetch  select * from capemp123; persist,merge,remove,find,createQuery

//		Query query = em.createQuery("select max(esal) from Employee ");//oracle
//		
//				Object obj=query.getSingleResult();
//				System.out.println(obj);
//		List<Employee> emps = query.getResultList();
//
//		for (Employee employee : emps) {
//			System.out.println(employee);
//		}

		// SELECT * FROM ericsson_emps; mysql

//		TypedQuery<Employee> q2 = em.createQuery("select a from Employee a", Employee.class);
//		List<Employee> l1 = q2.getResultList();
//			
//		for (Employee e4 : l1) {
//			System.out.println(e4);
//		}
//		int intialSal=10000;
//		int finalSal=35000;
//		
//		TypedQuery<Employee> q2 = em.createQuery("select a from Employee a where a.esal between ?1 and ?2", Employee.class);
//							q2.setParameter(1, intialSal);
//							q2.setParameter(2, finalSal);	
//		
//		List<Employee> l1 = q2.getResultList();
//			
//		for (Employee e4 : l1) {
//			System.out.println(e4);
//		}

		// update
		 //update ericsson_emps set salary=salary+5000  where salary<50000;
//		Query q = em.createQuery("update Employee set esal=esal+5000 where esal<50000");
//		int result=q.executeUpdate();
//			System.out.println(result+"records updated");
//		// delete
//		// delete from fis_emps where salary>30000 
//		  Query q3 = em.createQuery("delete from Employee e where e.esal>30000");
//		  q3.executeUpdate();
//		 
		Query query = em.createQuery("select max(emp.esal) FROM Employee emp");
		int sumsal = (int) query.getSingleResult();
		System.out.println(sumsal);
//		
		
//
//							student crud 5 getall student 
//		Query query1 = em.createNamedQuery("Employee.getMaxSal");
//		int maxsal1 = (int) query1.getSingleResult();
//		System.out.println(maxsal1);
//		
//		Query q2=em.createNativeQuery("fetchAll");
//		 List<Employee> l1 = q2.getResultList();	  
//		  for (Employee e4 : l1) {
//			  System.out.print(e4.getEid());
//		  System.out.print(" "+e4.getEname());// ...all 
//		  System.out.println(" "+e4.getEsal());
//		  }
		em.getTransaction().commit();
		// System.out.println("inserted");
		em.close();
		emf.close();

	}
}
