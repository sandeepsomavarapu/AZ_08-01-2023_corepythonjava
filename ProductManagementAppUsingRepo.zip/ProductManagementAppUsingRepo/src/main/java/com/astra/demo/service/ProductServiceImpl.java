package com.astra.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.astra.demo.exceptions.InvalidProduct;
import com.astra.demo.model.Product;
import com.astra.demo.repo.ProductRepo;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductRepo repo;

	@Override
	public String addProduct(Product product) {
		repo.save(product);
		return "Product Saved Successfully";
	}

	@Override
	public String updateProduct(Product product) {
		repo.save(product);
		return "Product Updated Successfully";
	}

	@Override
	public String deleteProduct(int productId) throws InvalidProduct {
			Product product=getProduct(productId);
			repo.delete(product);
		return "Product Deleted Successfully";
	}

	@Override
	public Product getProduct(int productId) throws InvalidProduct {
		Optional<Product> optional = repo.findById(productId);
		if (optional.isPresent())
			return optional.get();
		else
			throw new InvalidProduct("Product Id Invalid");
	}

	@Override
	public List<Product> getAllProducts() {

		return repo.findAll();
	}

	@Override
	public List<Product> getProductsBetweenPrice(int intialPrice, int finalPrice) {

		return repo.findByProductPriceBetween(intialPrice, finalPrice);
	}

	@Override
	public List<Product> getProductsByCateogry(String productCategory) {

		return repo.findByProductCategory(productCategory);
	}

	@Override
	public List<Product> getProductsByBrand(String productBrand) {

		return repo.findByProductBrand(productBrand);
	}

}
